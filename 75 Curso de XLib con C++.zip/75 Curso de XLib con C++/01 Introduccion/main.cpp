// -----------------------------------------------------------------------
// Curso de XLib con C++
// Introducción
// -----------------------------------------------------------------------

// Compilación
// g++ main.cpp -L/usr/X11R6/lib -lX11

// Verificas si lo tienes instalado
// apt search Xlib.h

// Instalar
// sudo apt install libx11-dev


// Instalaciones adicionales que se pueden realizar
// sudo apt-get install libx11-dev ................. for X11/Xlib.h
// sudo apt-get install mesa-common-dev............. for GL/glx.h
// sudo apt-get install libglu1-mesa-dev ........... for GL/glu.h
// sudo apt-get install libxrandr-dev .............. for X11/extensions/Xrandr.h
// sudo apt-get install libxi-dev .................. for X11/extensions/XInput.h

// Incluimos librerías
#include <X11/Xlib.h>
#include <unistd.h>

// Programa Principal
int main()
{
  // Open a display.
  Display *d = XOpenDisplay(0);

  // Verifica si puede crear el Display
  if ( d )
  {
      // Create the window
      Window w = XCreateWindow(d, DefaultRootWindow(d), 0, 0, 200,
			       100, 0, CopyFromParent, CopyFromParent,
			       CopyFromParent, 0, 0);

      // Show the window
      XMapWindow(d, w);
      XFlush(d);

      // Sleep long enough to see the window.
      sleep(10);
  }
  return 0;
}