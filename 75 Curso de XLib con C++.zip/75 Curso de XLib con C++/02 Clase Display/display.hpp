// -----------------------------------------------------------------------
// display.hpp
// -----------------------------------------------------------------------

// Incluimos la libreria
#include <X11/Xlib.h>

// Creamos la clase display
class display
{
    public:
        display()
        {
            // Open a display.
            Display *d = XOpenDisplay(0);
        };

};