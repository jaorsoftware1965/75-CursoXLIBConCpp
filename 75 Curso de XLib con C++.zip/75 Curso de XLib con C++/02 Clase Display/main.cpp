// -----------------------------------------------------------------------
// Curso de XLib con C++
// Introducción
// -----------------------------------------------------------------------

// Compilación
// g++ main.cpp -L/usr/X11R6/lib -lX11

// Verificas si lo tienes instalado
// apt search Xlib.h

// Instalar
// sudo apt install libx11-dev


#include <X11/Xlib.h>
#include <unistd.h>

// our stuff
#include "display.hpp"



main()
{
  // Open a display.
  display d("");

  if ( d )
    {
      // Create the window
      Window w = XCreateWindow((Display*)d,
			       DefaultRootWindow((Display*)d),
			       0, 0, 200, 100, 0, CopyFromParent,
			       CopyFromParent, CopyFromParent, 0, 0);

      // Show the window
      XMapWindow(d, w);
      XFlush(d);

      // Sleep long enough to see the window.
      sleep(10);
    }
  return 0;
}